<?php

class WPML_ACF_Link_Field extends WPML_ACF_Field {

	/**
	 * @return string ACF field type name.
	 */
	public function field_type() {
		return 'link';
	}

}
